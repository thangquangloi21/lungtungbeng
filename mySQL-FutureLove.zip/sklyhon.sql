-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 15, 2023 at 04:25 AM
-- Server version: 8.0.33-0ubuntu0.20.04.1
-- PHP Version: 7.4.3-4ubuntu2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `futureLove2`
--

-- --------------------------------------------------------

--
-- Table structure for table `sklyhon`
--

CREATE TABLE `sklyhon` (
  `id` int NOT NULL,
  `mask` mediumtext NOT NULL,
  `thongtin` mediumtext NOT NULL,
  `image` mediumtext NOT NULL,
  `nu` mediumtext,
  `nam` mediumtext,
  `dotuoi` int DEFAULT NULL,
  `danam` mediumtext,
  `danu` mediumtext,
  `ngswap` int DEFAULT NULL,
  `vtrinam` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `sklyhon`
--

INSERT INTO `sklyhon` (`id`, `mask`, `thongtin`, `image`, `nu`, `nam`, `dotuoi`, `danam`, `danu`, `ngswap`, `vtrinam`) VALUES
(1, 'LH', 'After 3 years of marriage, the husband and wife divorced because the husband had erectile dysfunction.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/Husband-unhappy-and-disappoint.jpg', '0', '0', 29, '5', '5', 0, 'nt'),
(2, 'LH', 'What happens after you two get married? The two of you will soon break up because your male friend is addicted to alcohol and drugs', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/alcohol-withdrawal-timeline-1.jpg', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/alcohol-withdrawal-timeline-1.jpg', '0', 23, NULL, '1', 1, 'nt'),
(3, 'LH', 'After visiting the hospital for a check-up, the husband discovered that he was infertile, but his wife had a child. So, whose child is it?', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/vo_sinh_nam.jpg', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/74.jpg', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/73.jpg', 34, '1', '1', 2, 'namtruoc'),
(4, 'LH', 'After 2 years of marriage, the husband and wife have divorced because the wife went to her husband\'s company to physically attack him out of jealousy, which impaired his mental well-being.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/couple_argument_yelling.jpg', '0', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/couple_argument_yelling.jpg', 32, '1', NULL, 1, 'namsau'),
(5, 'LH', 'After 2 years of marriage, the husband and wife divorced because the husband discovered that his wife had been having an affair with his brother and that their current child was not his own.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/998.jpg', '0', '0', 27, NULL, '1', 0, 'nt'),
(6, 'LH', 'After 1 year of marriage, the wife discovered that her husband was having an affair with her sister behind her back.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/1-1551953708604657186659.jpg', '0', '0', 35, NULL, '2', 0, 'nt'),
(7, 'LH', 'After 1 month of marriage, the wife requested a divorce because she found out that her husband was bisexual and had cheated on her with another man.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/2930_1.jpg', '0', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/2930_1.jpg', 34, '2', NULL, 1, 'namsau'),
(8, 'LH', 'The husband decided for divorce from his beautiful wife after discovering her deceit. She had never told him about her extensive plastic surgery to look as beautiful as she did.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/upset-chinese-man-woman-having-quarrel-kitchen-middle-aged-young-looking-opposite-sides-husband-wife-thinking-divorce-255720116.jpg', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/79.jpg', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/80.jpg', 30, '2', '2', 2, 'namsau'),
(9, 'LH', 'After 1 week of marriage, the wife decided to divorce because she discovered that her husband was not a wealthy heir like she had thought.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/12-Warning-Signs-Your-Marriage-Is-Over-According-To-Experts-6.jpg', '0', '0', 31, NULL, '1', 1, 'nt'),
(10, 'LH', 'The husband discovered that his wife had been deceiving him for many years. When they first started dating, she had claimed to be 24 years old, but in reality, she was 34 years old.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/photo1599731820862-15997318208681037861370-crop-1599731880352378356155.jpg', '0', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/photo1599731820862-15997318208681037861370-crop-1599731880352378356155.jpg', 33, '2', '2', 1, 'namtruoc'),
(11, 'LH', 'The husband requested a divorce because his wife was too violent. The wife found out that her husband was having an affair, so she grabbed a knife and hired someone to beat up the other woman.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/ngoai-tinh11-403.jpg', '0', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/ngoai-tinh11-403.jpg', 29, '2', '2', 2, 'namsau'),
(12, 'LH', 'After one month of marriage, the husband requested a divorce because his wife was too dirty. She only took a bath and washed her hair once a week.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/pexels-rhema-11790891-1.jpg', '0', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/pexels-rhema-11790891-1.jpg', 33, '3', NULL, 1, 'namtruoc'),
(13, 'LH', 'After their wedding night, the husband requested a divorce because he couldn\'t accept that his wife was no longer a virgin.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/phu-nu-con-trinh-2.jpg', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/88.jpg', '0', 22, NULL, '2', 1, 'nt'),
(14, 'LH', 'On their wedding night, the wife was extremely upset when she heard her newly-wed husband call her the wrong name, a name of another woman. The next day, she demanded a divorce.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/shutterstock_593479430.jpg', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/shutterstock_593479430.jpg', '0', 34, '1', '1', 1, 'nt'),
(15, 'LH', 'The husband insisted on divorcing because the shaman said that his wife was a demon who had bewitched him, always made trouble and took his money.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/women-rights-in-husband-property-after-divorce.jpg', '0', '0', 25, '1', '1', 2, 'namtruoc'),
(16, 'LH', 'How will the two of you be at 70 years old? The husband has taken another wife, and there are 3 people living together under the same roof.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/lay-hai-vo.jpg', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/93.jpg', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/94.jpg', 70, '1', '1', 2, 'namtruoc'),
(17, 'LH', 'How will the two of you be at 70 years old? The husband and wife were abandoned by their children and had to live together in a nursing home ', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/nqh03331-1617362160533182927786.jpg', '0', '0', 70, '2', NULL, 1, 'namtruoc'),
(18, 'LH', 'How will two friends be at 60 years old? At 60 years old, both friends will have passed away.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/vo%20chong.jpg', '0', '0', 60, '1', '1', 0, 'nt'),
(19, 'LH', 'How will two friends be at 60 years old? At 60 years old, the husband has died because the wife put poison in his food.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/loi-khai-roi-nuoc-mat-cua-nguoi-vo-len-bo-thuoc-doc-vao-thuc-an-cua-chong-suot-2-thang_1.jpg', '0', '0', 60, '1', NULL, 0, 'nt'),
(20, 'LH', 'After giving birth, the husband proposed a divorce to his wife because she was too sloppy.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/messy-lady.jpg', '0', '0', 24, NULL, '2', 0, 'nt'),
(21, 'LH', 'One week after getting married, the wife demanded a divorce because the husband slapped and hit her for talking too much.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/33227487-husband-wants-to-harm-his-wife-with-slap-domestic-violence.jpg', '0', '0', 36, '1', '1', 0, 'nt'),
(22, 'LH', 'After 2 months of marriage, the wife requested a divorce because her husband had erectile dysfunction.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/20131126085542-congai1.jpg', '0', '0', 27, '2', NULL, 2, 'namsau'),
(23, 'LH', 'At the age of 50, the husband requested a divorce after discovering that he had a serious illness.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/co-tich.jpg', '0', '0', 37, '2', '2', 1, 'namtruoc'),
(24, 'LH', 'After one year of marriage, the wife gave birth to their first daughter, but the husband demanded a divorce because his family did not like having a granddaughter.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/1_Stressed-Mother-Holding-Crying-Baby-Suffering-From-Post-Natal-Depression-At-Home.png', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/1_Stressed-Mother-Holding-Crying-Baby-Suffering-From-Post-Natal-Depression-At-Home.png', '0', 33, NULL, '1', 1, 'nt'),
(25, 'LH', 'After a year of marriage, the wife had an affair with the father-in-law and had a child with him. The husband discovered and requested a divorce. The wife then married the father-in-law, and the husband and wife continued living together and called each other mother and son.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/photo1595839489548-15958394895591286687615-crop-15958395965421888302794.jpg', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/109.jpg', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/108.jpg', 49, '4', '4', 2, 'namtruoc'),
(26, 'LH', 'While shopping, the wife discovered that her husband had lied about going on a business trip. In truth, she caught him cuddling with her best friend.', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sklyhon`
--
ALTER TABLE `sklyhon`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
