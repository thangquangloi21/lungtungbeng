-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 15, 2023 at 04:25 AM
-- Server version: 8.0.33-0ubuntu0.20.04.1
-- PHP Version: 7.4.3-4ubuntu2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `futureLove2`
--

-- --------------------------------------------------------

--
-- Table structure for table `sknym`
--

CREATE TABLE `sknym` (
  `id` int NOT NULL,
  `mask` mediumtext NOT NULL,
  `thongtin` mediumtext NOT NULL,
  `image` mediumtext NOT NULL,
  `nu` mediumtext,
  `nam` mediumtext,
  `dotuoi` int DEFAULT NULL,
  `danam` mediumtext,
  `danu` mediumtext,
  `ngswap` int DEFAULT NULL,
  `vtrinam` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `sknym`
--

INSERT INTO `sknym` (`id`, `mask`, `thongtin`, `image`, `nu`, `nam`, `dotuoi`, `danam`, `danu`, `ngswap`, `vtrinam`) VALUES
(1, 'NYM', 'One week after breaking up, at her wedding, you caught a glimpse of her older sister. And both of you fell in love after that wedding.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/saostar-le6fhlsuzpwzbgwf.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/nnu1.png', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/nnam1.png', 27, '1', '1', 2, 'nt'),
(2, 'NYM', 'What will you be like after 3 years of breaking up? Will you have to get back with your ex because you couldn\'t pay off all your debts to them?', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/nym4.jpg', '0', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/nym4.jpg', 27, '5', '5', 1, 'nt'),
(3, 'NYM', 'You will have a new lover at your ex-girlfriend\'s wedding, and that will be her best friend.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/nym5.jpg', '0', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/nym5.jpg', 25, '5', '5', 1, 'nt'),
(4, 'NYM', 'The wife discovered that her husband had proposed to break up with his ex-girlfriend because her family was too poor. He had fallen in love with the wife because of material possessions.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/chia-tay-ban-gai-doi-300-trieu-tien-phi-qua-3-nam-toi-bat-khoc-nhin-nguoi-ben-canh-em-1_248726-1623952986-194-width640height480.jpg', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/chia-tay-ban-gai-doi-300-trieu-tien-phi-qua-3-nam-toi-bat-khoc-nhin-nguoi-ben-canh-em-1_248726-1623952986-194-width640height480.jpg', '0', 30, '', '2', 1, 'nt'),
(5, 'NYM', 'At the age of 35, the husband and wife will reunite and proceed to marriage.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/nym1.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/nym2nu.png', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/nym1nam.png', 35, '2', '2', 2, 'namtruoc'),
(6, 'NYM', 'At the age of 40, the wife returned to her husband because at that time he was a wealthy heir.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/happy-wife-welcoming-her-military-husband-after-returning-back-home-from-army_116547-17523.jpg', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/happy-wife-welcoming-her-military-husband-after-returning-back-home-from-army_116547-17523.jpg', '0', 40, '', '3', 1, 'nt'),
(7, 'NYM', 'After the breakup, the husband returned to his ex-girlfriend because she was more beautiful than his wife.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/nym6.jpg', '0', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/nym6.jpg', 30, '5', '5', 1, 'nt'),
(8, 'NYM', 'At 50 years old, how will the two of you be? The husband already has a new girlfriend, who is a famous singer.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/ct11.jpg', '0', '0', 50, '1', '', 1, 'nt'),
(9, 'NYM', 'At 30 years old, who will be in your family? The family consists of 7 people: the husband, the wife, and 5 children.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/nym7.jpg', '0', '0', 30, '5', '5', 0, 'nt'),
(10, 'NYM', 'After the husband and wife broke up, the husband fell in love with his  best friend and they got married. After a year, they broke up because the husband realized he still loved his ex-wife.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/nym3.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/nym3nu.png', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/nym3nam.png', 40, '4', '4', 2, 'namtruoc'),
(11, 'NYM', 'After breaking up, the husband discovered that he was the third sex. Husband and husband\'s best friend fell in love', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/dong-tinh-luyen-ai-do-dau11453804634.jpg', '0', '0', 45, '1', '', 1, 'nt'),
(12, 'NYM', 'One week after breaking up with his wife, the husband started dating his teacher who is 20 years older than him.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/nym8.jpg', '0', '0', 25, '5', '5', 0, 'nt'),
(13, 'NYM', 'After 2 weeks of breaking up, the wife was proposed by the husband\'s older brother. The wife and the older brother got married and lived together under the same roof.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/nym9.jpeg', '0', '0', 27, '5', '5', 0, 'nt');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sknym`
--
ALTER TABLE `sknym`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
