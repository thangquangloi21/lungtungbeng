-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 15, 2023 at 04:25 AM
-- Server version: 8.0.33-0ubuntu0.20.04.1
-- PHP Version: 7.4.3-4ubuntu2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `futureLove2`
--

-- --------------------------------------------------------

--
-- Table structure for table `skhanhphuc`
--

CREATE TABLE `skhanhphuc` (
  `id` int NOT NULL,
  `mask` mediumtext NOT NULL,
  `thongtin` mediumtext NOT NULL,
  `image` mediumtext NOT NULL,
  `nu` mediumtext,
  `nam` mediumtext,
  `dotuoi` int DEFAULT NULL,
  `danam` mediumtext,
  `danu` mediumtext,
  `ngswap` int DEFAULT NULL,
  `vtrinam` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `skhanhphuc`
--

INSERT INTO `skhanhphuc` (`id`, `mask`, `thongtin`, `image`, `nu`, `nam`, `dotuoi`, `danam`, `danu`, `ngswap`, `vtrinam`) VALUES
(1, 'HP', 'You will be taken on a trip by your lover, and the two of you will have fun days together.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/hp1.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/hp1nu.png', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/hp1nam.png', 27, '2', '2', 2, 'namtruoc'),
(2, 'HP', 'You will be taken by your partner to meet their family, to ask for permission to marry you.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/hp5.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/hp5nu.png', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/hp5nam.png', 36, '1', '1', 2, 'namtruoc'),
(3, 'HP', 'You will be given gifts by your lover not on the occasion of a holiday at all', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/hp3.jpg', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/hp3.jpg', '0', 25, '1', '1', 1, 'nt'),
(4, 'HP', 'He will give you a Rolls-Royce car as a birthday present.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/awi1674345583%20(1).png', '0', '0', 32, '1', '1', 1, 'nt'),
(5, 'HP', 'You will receive a surprise gift from your significant other. Your family will have a new baby.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/hp8.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/hp8nu.png', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/hp8nam.png', 35, '1', '1', 2, 'namtruoc'),
(6, 'HP', 'Three years later, you two will be able to buy a villa.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/hp9.jpg', '0', '0', 30, '3', '3', 2, 'namtruoc'),
(7, 'HP', 'In 3 years, you will become a billionaire.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/hp13.jpg', '0', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/hp13.jpg', 39, '1', '', 1, 'nt'),
(8, 'HP', 'After 1 year of being in a relationship, you will be fattened up by your significant other by 10 kg.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/hp11.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/hp11.jpg', '0', 30, '', '1', 1, 'nt'),
(9, 'HP', 'At the age of 30, the husband will take his family on a world tour using his own airplane.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/hp12.jpg', '0', '0', 50, '1', '1', 2, 'namsau'),
(10, 'HP', 'At 37 years old, the husband and wife both became a nationally famous acting couple.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/hp14.jpg', '0', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/hp14.jpg', 42, '1', '1', 2, 'namtruoc'),
(11, 'HP', 'After discovering her husband\'s affair with his ex-girlfriend, the wife went to the ex-girlfriend\'s house to confront her and even resorted to cutting her hair and physically assaulting her.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/anh-chup-man-hinh-2021-04-06-luc-71937-sa-16176697300021258296524.png', '0', '0', 33, '', '2', 0, 'nt'),
(12, 'HP', 'After getting married, the husband and wife inherited a large amount of assets from the husband\'s stepfather.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/hp16.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/hp16nu.png', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/hp16nam.png', 40, '1', '1', 2, 'namtruoc');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `skhanhphuc`
--
ALTER TABLE `skhanhphuc`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
