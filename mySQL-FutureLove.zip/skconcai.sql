-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 15, 2023 at 04:25 AM
-- Server version: 8.0.33-0ubuntu0.20.04.1
-- PHP Version: 7.4.3-4ubuntu2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `futureLove2`
--

-- --------------------------------------------------------

--
-- Table structure for table `skconcai`
--

CREATE TABLE `skconcai` (
  `id` int NOT NULL,
  `mask` mediumtext NOT NULL,
  `thongtin` mediumtext NOT NULL,
  `image` mediumtext NOT NULL,
  `nu` mediumtext NOT NULL,
  `nam` mediumtext NOT NULL,
  `dotuoi` int NOT NULL,
  `danam` mediumtext NOT NULL,
  `danu` mediumtext NOT NULL,
  `ngswap` int DEFAULT NULL,
  `vtrinam` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `skconcai`
--

INSERT INTO `skconcai` (`id`, `mask`, `thongtin`, `image`, `nu`, `nam`, `dotuoi`, `danam`, `danu`, `ngswap`, `vtrinam`) VALUES
(1, 'CON', 'At 36 years old, the husband and wife had to sell their house to hire a lawyer because their son impregnated a 15-year-old girlfriend.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/cc1.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/cc1nu.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/cc1nam.jpg', 35, '1', '1', 2, 'nt'),
(2, 'CON', 'After getting married, the husband and wife had a son. At 20 years old, their son became a successful businessman, while the husband and wife remained penniless.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/cc2.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/cc2nu.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/cc2nam.jpg', 50, '4', '4', 2, 'namsau'),
(3, 'CON', 'After getting married, the husband and wife had a son. The husband and wife had to sell their house because their son was a chip off the old block and liked to party like his father.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/cc3.jpg', '0', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/cc3.jpg', 35, '2', '', 1, '0'),
(4, 'CON', 'After getting married, the husband and wife had a son. The husband and wife were surprised to discover that their son was a third gender person.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/cc4.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/cc4.jpg', '0', 40, '', '2', 1, '0'),
(5, 'CON', 'After getting married, the husband and wife had a child. During an argument, the child accidentally found out that they were the result of their mother\'s affair with an ex-lover.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/cc5.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/cc5.jpg', '0', 40, '', '1', 1, '0'),
(6, 'CON', 'After getting married, the husband and wife had a child. They were surprised when their son brought home his girlfriend, who turned out to be the husband\'s ex-girlfriend.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/cc6.jpg', '0', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/cc6.jpg', 45, '1', '', 1, '0'),
(7, 'CON', 'After their son got married, the wife was surprised to discover that her husband had been having an affair with their daughter-in-law and had a child with her.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/cc7.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/cc7.jpg', '0', 40, '', '1', 1, '0'),
(8, 'CON', 'After getting married, the husband and wife had a set of twins. When the twins grew up, they unexpectedly developed romantic feelings for each other.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/cc8.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/cc8nu.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/cc8nam.jpg', 40, '2', '2', 2, 'namsau');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `skconcai`
--
ALTER TABLE `skconcai`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
