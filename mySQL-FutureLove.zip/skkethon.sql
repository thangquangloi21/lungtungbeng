-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 15, 2023 at 04:25 AM
-- Server version: 8.0.33-0ubuntu0.20.04.1
-- PHP Version: 7.4.3-4ubuntu2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `futureLove2`
--

-- --------------------------------------------------------

--
-- Table structure for table `skkethon`
--

CREATE TABLE `skkethon` (
  `id` int NOT NULL,
  `mask` mediumtext NOT NULL,
  `thongtin` mediumtext NOT NULL,
  `image` mediumtext NOT NULL,
  `nu` mediumtext,
  `nam` mediumtext,
  `dotuoi` int DEFAULT NULL,
  `danam` mediumtext,
  `danu` mediumtext,
  `ngswap` int DEFAULT NULL,
  `vtrinam` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `skkethon`
--

INSERT INTO `skkethon` (`id`, `mask`, `thongtin`, `image`, `nu`, `nam`, `dotuoi`, `danam`, `danu`, `ngswap`, `vtrinam`) VALUES
(1, 'KH', 'On a fine day, you get good news. The couple had 1 baby and decided to get married. After 1 year together, you suddenly realize that the child is not yours', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/transracial-adoption-racial-identity-single-parent-LGBT.jpg', '0', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/transracial-adoption-racial-identity-single-parent-LGBT.jpg', 30, '1', NULL, 1, 'namsau'),
(2, 'KH', 'You and she are prevented by your family from coming together. You are forced to marry someone else. For 6 months of marriage, you could not forget about her and had an affair with her', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/featuredImageId26280.jpg', '0', '0', 25, '1', '1', 0, 'nt'),
(3, 'KH', 'You two are married, one day you are walking down the street to find out he is a third sex, he has been hiding from you for so long', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/77367839.jpg', '0', '0', 27, '1', '1', 2, 'namsau'),
(4, 'KH', 'What happens to you after marriage? You find out he has been having an affair with your best friend. You\'re glad there was a reason to break up, because you\'re having an affair too.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/ngoai-tinh.jpg', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/48.jpg', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/49.jpg', 25, '1', '1', 2, 'namsau'),
(5, 'KH', 'One year after dating, they decided to get married. However, during their wedding night, the husband suddenly felt a strong, uncomfortable odor around him. When he kept asking, the bride finally shyly admitted that she had an issue with body odor.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/999.jpg', '0', '0', 33, '1', '1', 2, 'namsau'),
(6, 'KH', 'The husband and wife were prevented from being together by their families, and the husband was forced to marry someone else. After 6 months of marriage, the husband realized he still loved his ex-wife and had an affair with her.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/tinh-yeu-bi-ngan-cam-boi-gia-dinh-1.jpg', '0', '0', 30, '1', '1', 0, 'nt'),
(7, 'KH', 'On the day of the wedding of the two, the husband met his ex-girlfriend again and developed feelings for her. In the first month of their marriage, the husband secretly contacted his ex-girlfriend.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/kh4.jpg', '0', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/kh4.jpg', 26, '1', '1', 2, 'namtruoc'),
(8, 'KH', 'On the wedding day of the couple, the husband had a traffic accident on the way to pick up his wife, was hospitalized, and the wedding ceremony was postponed.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/GettyImages-1230331949-1000x667.jpg', '0', '0', 40, '2', '2', 0, 'nt'),
(9, 'KH', 'One month after getting married, the husband hit his wife because she didn\'t do housework.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/bao-luc-gia-dinh-hien-nay-1200x800-1633638359165423145265-0-128-670-1200-crop-1633638367567377342296.jpg', '0', '0', 32, '1', '1', 0, 'nt'),
(10, 'KH', 'One week after getting married, the husband lost his memory, forgot his wife, and asked for a divorce. The husband only remembered his ex-girlfriend.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/718aa9a4aae643b81af7.jpg', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/718aa9a4aae643b81af7.jpg', '0', 42, '2', '2', 2, 'namsau'),
(11, 'KH', 'The wife secretly had an affair with the neighbor because her husband had erectile dysfunction.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/chong-cuong-an-ai-1131.jpg', '0', '0', 30, '2', '2', 0, 'nt'),
(12, 'KH', 'After 2 years of marriage, the couple went bankrupt because the husband spent all the money on entertainment and girls.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/depositphotos_53691311-stock-photo-broke-bankrupt-young-couple.jpg', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/62.jpg', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/63.jpg', 31, '1', '1', 2, 'namsau'),
(13, 'KH', 'The couple had a child, and the husband brought his wife home to introduce her to the family, but they were rejected because the family only liked the husband\'s ex-girlfriend.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/khonghoahop.jpg', '0', '0', 35, NULL, '2', 0, 'nt'),
(14, 'KH', 'After one week of marriage, the wife asked for a divorce upon discovering that her husband had a child with his ex-girlfriend.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/its-time-to-divorce.jpg', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/65.jpg', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/66.jpg', 27, '1', '1', 2, 'namsau'),
(15, 'KH', 'At 45 years old, the couple\'s son will marry the ex-girlfriend of the husband and the three of them will live together under one roof.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/chup-anh-gia-dinh-4-nguoi-6-1.png', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/67.png', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/68.png', 43, '2', '2', 2, 'namsau'),
(16, 'KH', 'At 46 years old, one year after their son married his ex-girlfriend and had a child, the wife discovered that the child was actually her husband\'s.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/sinhcongai1-min.jpg', '0', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/sinhcongai1-min.jpg', 23, '2', '2', 0, 'nt');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `skkethon`
--
ALTER TABLE `skkethon`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
