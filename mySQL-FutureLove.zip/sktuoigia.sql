-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 15, 2023 at 04:24 AM
-- Server version: 8.0.33-0ubuntu0.20.04.1
-- PHP Version: 7.4.3-4ubuntu2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `futureLove2`
--

-- --------------------------------------------------------

--
-- Table structure for table `sktuoigia`
--

CREATE TABLE `sktuoigia` (
  `id` int NOT NULL,
  `mask` mediumtext,
  `thongtin` mediumtext,
  `image` mediumtext,
  `nu` mediumtext,
  `nam` mediumtext,
  `dotuoi` int DEFAULT NULL,
  `danam` mediumtext,
  `danu` mediumtext,
  `ngswap` int DEFAULT NULL,
  `vtrinam` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `sktuoigia`
--

INSERT INTO `sktuoigia` (`id`, `mask`, `thongtin`, `image`, `nu`, `nam`, `dotuoi`, `danam`, `danu`, `ngswap`, `vtrinam`) VALUES
(1, 'TG', 'After getting married, the husband and wife lived happily together until they were 99 years old.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/tai-hinh-anh-vo-chong-gia-di-hanh-phuc.jpg', '0', '0', 99, '2', '2', 0, 'nt'),
(2, 'TG', 'At the age of 60, the husband had an affair with a 35-year-old woman, despite the opposition from his wife and children.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/118.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/nu118.png', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/nam118.png', 60, '2', '2', 2, 'namsau'),
(3, 'TG', 'At 70 years old, the husband and wife became homeless because their daughter-in-law, who is the ex-girlfriend of the husband, kicked them out of the house.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/118.jpg', '0', '0', 70, '5', '5', 0, 'nt'),
(4, 'TG', 'At the age of 70, the husband discovered he was infertile and requested a divorce because the wife had four children with someone else.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/118.jpg', '', '', 70, '5', '5', 0, 'nt'),
(5, 'TG', 'Due to old age and illness, the husband had been bedridden since he turned 60. The wife left him and got together with a wealthy man who was 10 years younger than her.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/118.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 'TG', 'After the husband passed away, the wife reunited with her ex-lover after years of being apart. The wife and her ex-lover lived happily together and got married.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/118.jpg', NULL, NULL, 55, NULL, NULL, NULL, NULL),
(7, 'TG', 'The wife discovered that her husband was having an affair with their son\'s girlfriend. They had been secretly seeing each other for four months.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/118.jpg', NULL, NULL, 70, NULL, NULL, NULL, NULL),
(8, 'TG', 'The wife discovered that her husband was having an affair with a woman who was 40 years younger than him.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/118.jpg', NULL, NULL, 60, NULL, NULL, NULL, NULL),
(9, 'TG', 'At the age of 55, the husband passed away due to excessive sexual activity that weakened his health.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/118.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sktuoigia`
--
ALTER TABLE `sktuoigia`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
