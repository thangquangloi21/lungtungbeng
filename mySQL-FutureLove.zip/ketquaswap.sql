-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 15, 2023 at 04:25 AM
-- Server version: 8.0.33-0ubuntu0.20.04.1
-- PHP Version: 7.4.3-4ubuntu2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `futureLove2`
--

-- --------------------------------------------------------

--
-- Table structure for table `ketquaswap`
--

CREATE TABLE `ketquaswap` (
  `swapct` text NOT NULL,
  `swapnym` text NOT NULL,
  `swaphp` text NOT NULL,
  `swapms` text NOT NULL,
  `swaplyhon` text NOT NULL,
  `swapkh` text NOT NULL,
  `id_swap` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `ketquaswap`
--

INSERT INTO `ketquaswap` (`swapct`, `swapnym`, `swaphp`, `swapms`, `swaplyhon`, `swapkh`, `id_swap`) VALUES
('https://i.ibb.co/yQBVR5T/407721f7ef8b.jpg', 'https://i.ibb.co/yQBVR5T/407721f7ef8b.jpg', 'https://i.ibb.co/yQBVR5T/407721f7ef8b.jpg', 'https://i.ibb.co/yQBVR5T/407721f7ef8b.jpg', 'https://i.ibb.co/yQBVR5T/407721f7ef8b.jpg', 'https://i.ibb.co/yQBVR5T/407721f7ef8b.jpg', 1),
('https://i.ibb.co/Vg0D256/80355fff336a.jpg', 'https://i.ibb.co/58NkShX/0248830d5866.jpg', 'https://i.ibb.co/HdjhzbR/0d55a012fb96.png', 'https://i.ibb.co/X8NYZ2P/3dc0ddef78a4.jpg', 'https://i.ibb.co/f2cdV6S/c9a26d800841.jpg', 'https://i.ibb.co/RNY6Ldh/421569c9dc87.jpg', 3),
('https://i.ibb.co/yQBVR5T/407721f7ef8b.jpg', 'https://i.ibb.co/yQBVR5T/407721f7ef8b.jpg', 'https://i.ibb.co/yQBVR5T/407721f7ef8b.jpg', 'https://i.ibb.co/yQBVR5T/407721f7ef8b.jpg', 'https://i.ibb.co/yQBVR5T/407721f7ef8b.jpg', 'https://i.ibb.co/yQBVR5T/407721f7ef8b.jpg', 2),
('https://i.ibb.co/1GbkJsz/a26eb3fde7ad.jpg', 'https://i.ibb.co/BCRz3Zc/5a35a6074f3d.jpg', 'https://i.ibb.co/9TWQtmq/c3064a7b4194.png', 'https://i.ibb.co/X8NYZ2P/3dc0ddef78a4.jpg', 'https://i.ibb.co/X2LNbJZ/cf0790dbe507.jpg', 'https://i.ibb.co/nwZrvkN/d5be371ca81f.jpg', 4),
('https://i.ibb.co/J2PHY36/d2be2b6c5958.jpg', 'https://i.ibb.co/z2j39FD/fc71f55e7d90.jpg', 'https://i.ibb.co/k1jCbpZ/1abcd549f127.jpg', 'https://i.ibb.co/rQywRHP/7934d0c2acc5.jpg', 'https://i.ibb.co/sWX28C9/e2b5884848cb.jpg', 'https://i.ibb.co/dP7JS2n/4e72fb09006e.jpg', 5),
('https://i.ibb.co/xHtWLL2/761f8f17cd26.jpg', 'https://i.ibb.co/0t56SqV/a2c1d6410a1c.jpg', 'https://i.ibb.co/vZNk6Pg/2d92c159d4da.jpg', 'https://i.ibb.co/mFLsk5w/00dce375374c.jpg', 'https://i.ibb.co/fvKnbrb/c30b1f60fc58.jpg', 'https://i.ibb.co/7Wk6kcv/d01aacd0f24b.jpg', 6),
('https://i.ibb.co/J2PHY36/d2be2b6c5958.jpg', 'https://i.ibb.co/C5ZrXn4/29e95c08de3a.jpg', 'https://i.ibb.co/SPN6n38/b9bcb54a95b6.jpg', 'https://i.ibb.co/zmt1T27/3ef024c14fe8.jpg', 'https://i.ibb.co/m60KbKs/5900886d3274.jpg', 'https://i.ibb.co/K20D3t0/2b33fad0ebd9.jpg', 7),
('https://i.ibb.co/Vg0D256/80355fff336a.jpg', 'https://i.ibb.co/gRnSSL8/88acbcce23e9.jpg', 'https://i.ibb.co/7QKZkfH/20a2c1ea9c70.jpg', 'https://i.ibb.co/GJP5XtQ/156fa2de71a4.jpg', 'https://i.ibb.co/Jd2hCjt/1a815c66465c.jpg', 'https://i.ibb.co/Sm14dL5/9cf192787eb8.jpg', 8),
('https://i.ibb.co/jJfzL99/bc77cbff1fb6.jpg', 'https://i.ibb.co/7g5hCLz/2c440cca9cad.jpg', 'https://i.ibb.co/pzHsF4n/3fa8e295dceb.jpg', 'https://i.ibb.co/CQ0P9r6/7694c9abed03.jpg', 'https://i.ibb.co/rs59H3R/90b9d5bbf697.jpg', 'https://i.ibb.co/sbbkt5T/9c3c40023859.jpg', 9),
('https://i.ibb.co/bNz5pNN/d21b57adf3a1.jpg', 'https://i.ibb.co/fv7SZYD/e91d10b19795.jpg', 'https://i.ibb.co/1dbcJZD/fbb8bd790b91.jpg', 'https://i.ibb.co/KX5vVLg/09596ce2ef4c.jpg', 'https://i.ibb.co/KX5vVLg/09596ce2ef4c.jpg', 'https://i.ibb.co/vzXb8CX/082f8de8c170.jpg', 10),
('https://i.ibb.co/X8NYZ2P/3dc0ddef78a4.jpg', 'https://i.ibb.co/KX5vVLg/09596ce2ef4c.jpg', 'https://i.ibb.co/vzXb8CX/082f8de8c170.jpg', 'https://i.ibb.co/1dbcJZD/fbb8bd790b91.jpg', 'https://i.ibb.co/vzXb8CX/082f8de8c170.jpg', 'https://i.ibb.co/fv7SZYD/e91d10b19795.jpg', 11),
('https://i.ibb.co/s3kVk5t/b8c45fec0b51.jpg', 'https://i.ibb.co/mqnRm5s/179c76c2408f.jpg', 'https://i.ibb.co/vzXb8CX/082f8de8c170.jpg', 'https://i.ibb.co/fv7SZYD/e91d10b19795.jpg', 'https://i.ibb.co/X8NYZ2P/3dc0ddef78a4.jpg', 'https://i.ibb.co/zmt1T27/3ef024c14fe8.jpg', 12),
('https://i.ibb.co/JyNzG9R/440c8cdcb40b.jpg', 'https://i.ibb.co/JyNzG9R/440c8cdcb40b.jpg', 'https://i.ibb.co/L6ckTFG/4888d7daf897.jpg', 'https://i.ibb.co/L6ckTFG/4888d7daf897.jpg', 'https://i.ibb.co/mT7fKBF/85d5e21b2067.jpg', 'https://i.ibb.co/X8NYZ2P/3dc0ddef78a4.jpg', 13),
('https://i.ibb.co/x7ryR8q/c859a2cab984.jpg', 'https://i.ibb.co/9cM5gxm/9c5dca706a31.jpg', 'https://i.ibb.co/9TWQtmq/c3064a7b4194.png', 'https://i.ibb.co/fv7SZYD/e91d10b19795.jpg', 'https://i.ibb.co/f2cdV6S/c9a26d800841.jpg', 'https://i.ibb.co/sbbkt5T/9c3c40023859.jpg', 14),
('https://i.ibb.co/KKMhyYM/deaa844c3adb.jpg', 'https://i.ibb.co/Krr1fjZ/402d113483fb.jpg', 'https://i.ibb.co/jG6rGGb/ebd2776fd928.png', 'https://i.ibb.co/BPNK1mD/4ef78caf61db.jpg', 'https://i.ibb.co/Kb0hHPY/3cf74f752dfa.jpg', 'https://i.ibb.co/YyBcXxz/a7cead5994e0.jpg', 15),
('https://i.ibb.co/S3vv3Tz/5b4c74a3ac71.jpg', 'https://i.ibb.co/wRHwrhw/34a6be87f29c.jpg', 'https://i.ibb.co/1LfM7C9/eb1beeaf69b8.jpg', 'https://i.ibb.co/PNYJZBs/4392288380a9.jpg', 'https://i.ibb.co/XWH37R0/467a746dbb2e.jpg', 'https://i.ibb.co/Rg8NrBL/1a7ed88edbb7.jpg', 16),
('https://i.ibb.co/sP2F7h6/5350b9115d12.jpg', 'https://i.ibb.co/HgTQL1d/ef289cca4348.jpg', 'https://i.ibb.co/xq4KszW/74b35c1ca524.jpg', 'https://i.ibb.co/tB60CSL/d5d55c79a8ab.jpg', 'https://i.ibb.co/FnnNcXj/9283e4527e94.jpg', 'https://i.ibb.co/7SS2d55/5e94b17be8a3.jpg', 17),
('https://i.ibb.co/C72bCb0/6d8ca825c306.jpg', 'https://i.ibb.co/3k3NhR4/0a8ee9f861da.jpg', 'https://i.ibb.co/F7zskWk/08287e9c7708.jpg', 'https://i.ibb.co/7vgQ3cc/b261e13dc075.jpg', 'https://i.ibb.co/Ms1X7vp/212852dd29c7.jpg', 'https://i.ibb.co/qWLWrf5/275b58e13bc6.jpg', 18),
('https://i.ibb.co/sqS4rpF/ec34c134c0f8.jpg', 'https://i.ibb.co/ZMPS45b/9c2e8c930fb4.jpg', 'https://i.ibb.co/vH1zg1R/532e5bccf373.jpg', 'https://i.ibb.co/kQNHrnz/064125554889.jpg', 'https://i.ibb.co/TkRSVrJ/afe820e84c50.jpg', 'https://i.ibb.co/5nTv8ZX/711599a33b02.jpg', 19),
('https://i.ibb.co/k57b4XV/7d7bfe9d3b49.jpg', 'https://i.ibb.co/71qjDy8/390f2b51ea9c.jpg', 'https://i.ibb.co/n12TTL6/ef6916153774.jpg', 'https://i.ibb.co/V3QStCb/77f454ffc8ff.jpg', 'https://i.ibb.co/Lh73Fsn/1d9fae90bfe3.jpg', 'https://i.ibb.co/5B2pjyG/34ba536913c9.jpg', 20),
('https://i.ibb.co/WWBGpVy/bdfac855a661.jpg', 'https://i.ibb.co/DtdwNvN/26d83483e7db.jpg', 'https://i.ibb.co/jG6rGGb/ebd2776fd928.png', 'https://i.ibb.co/jyCwhVq/5fdbf1e25fd2.jpg', 'https://i.ibb.co/zncDBr6/05d7254c640b.jpg', 'https://i.ibb.co/ZcZVPcg/e66e7094c406.jpg', 21),
('https://i.ibb.co/wp9Vy3f/6c56fbb02eef.jpg', 'https://i.ibb.co/mhfbf6j/3c04a4f9dee8.jpg', 'https://i.ibb.co/BPr5yPK/281ef1d9c6b4.jpg', 'https://i.ibb.co/tB60CSL/d5d55c79a8ab.jpg', 'https://i.ibb.co/Ms1X7vp/212852dd29c7.jpg', 'https://i.ibb.co/ZcZVPcg/e66e7094c406.jpg', 22),
('https://i.ibb.co/z6VVZkB/e6dc3ec5bcf3.jpg', 'https://i.ibb.co/ThnRqTg/3017be6f688d.jpg', 'https://i.ibb.co/r41QWgS/bc8ebf36d934.jpg', 'https://i.ibb.co/tB60CSL/d5d55c79a8ab.jpg', 'https://i.ibb.co/fdzTWDB/bf8581efbbdb.jpg', 'https://i.ibb.co/Sx7NSLN/74e0be740e53.jpg', 23),
('https://i.ibb.co/GCHK9LZ/b527f39a61de.jpg', 'https://i.ibb.co/nMYD0L6/08c213001eee.jpg', 'https://i.ibb.co/s2f9z5m/b070969443e6.jpg', 'https://i.ibb.co/wKRNGkD/5e80421e9f54.jpg', 'https://i.ibb.co/gy3pcRM/739bd3f278b6.jpg', 'https://i.ibb.co/7SS2d55/5e94b17be8a3.jpg', 24),
('https://i.ibb.co/k57b4XV/7d7bfe9d3b49.jpg', 'https://i.ibb.co/DQJSdSD/8dee1297cf90.jpg', 'https://i.ibb.co/qBNt0zm/8047de3e0672.jpg', 'https://i.ibb.co/B4fxg43/3371f6d54eb1.jpg', 'https://i.ibb.co/RQNWpsX/8da606b05080.jpg', 'https://i.ibb.co/nn3TMmk/8aedc5b37f8a.jpg', 25),
('https://i.ibb.co/WWBGpVy/bdfac855a661.jpg', 'https://i.ibb.co/DQJSdSD/8dee1297cf90.jpg', 'https://i.ibb.co/hmdVvc2/8b6309626656.jpg', 'https://i.ibb.co/GJGchFR/3ec7ceb1ea3d.jpg', 'https://i.ibb.co/Zzt3RJ7/da0ce365f435.jpg', 'https://i.ibb.co/s5qfFBh/76bfcd57f949.jpg', 26),
('https://i.ibb.co/72XFf3n/fd5f9e6a321b.jpg', 'https://i.ibb.co/DQJSdSD/8dee1297cf90.jpg', 'https://i.ibb.co/1X3g0Rh/24e004a64356.jpg', 'https://i.ibb.co/288bgcx/d9d1e0354270.jpg', 'https://i.ibb.co/4Z9cN4X/ffdf2bd52948.jpg', 'https://i.ibb.co/5nTv8ZX/711599a33b02.jpg', 27),
('https://i.ibb.co/3TBQybd/6674e631aadf.jpg', 'https://i.ibb.co/ZMPS45b/9c2e8c930fb4.jpg', 'https://i.ibb.co/wgfkGTT/0289755be0f5.jpg', 'https://i.ibb.co/JmHrHYn/67369c4d59a8.jpg', 'https://i.ibb.co/8YCYxVD/65952525876a.jpg', 'https://i.ibb.co/3yzhHPm/8dc8089ef9d5.jpg', 28),
('https://i.ibb.co/z6VVZkB/e6dc3ec5bcf3.jpg', 'https://i.ibb.co/ThnRqTg/3017be6f688d.jpg', 'https://i.ibb.co/s96PNXN/8a11e782da57.jpg', 'https://i.ibb.co/vX9R7fk/bb5c387d35d4.jpg', 'https://i.ibb.co/3BszzM6/b19aed55b4ea.jpg', 'https://i.ibb.co/bJ8790N/477eeedd4ea1.jpg', 29),
('https://i.ibb.co/C72bCb0/6d8ca825c306.jpg', 'https://i.ibb.co/NWyQTbt/b8f8077ae09f.jpg', 'https://i.ibb.co/fYLvFB9/8b6a0b4dc061.png', 'https://i.ibb.co/tB60CSL/d5d55c79a8ab.jpg', 'https://i.ibb.co/0yGSZsY/64a9a93b8698.jpg', 'https://i.ibb.co/17mFhZ0/abd5c55090a4.jpg', 30),
('https://i.ibb.co/KrNSkJH/bb591a16d49a.jpg', 'https://i.ibb.co/DQJSdSD/8dee1297cf90.jpg', 'https://i.ibb.co/fYLvFB9/8b6a0b4dc061.png', 'https://i.ibb.co/BcVk9Nh/fee64b13d61c.jpg', 'https://i.ibb.co/bmzMfxW/afa850c32b2c.jpg', 'https://i.ibb.co/Bcmf34g/f30c21207230.jpg', 31),
('https://i.ibb.co/60bwG0f/e498d22d7622.jpg', 'https://i.ibb.co/ZMPS45b/9c2e8c930fb4.jpg', 'https://i.ibb.co/xq4KszW/74b35c1ca524.jpg', 'https://i.ibb.co/288bgcx/d9d1e0354270.jpg', 'https://i.ibb.co/Ms1X7vp/212852dd29c7.jpg', 'https://i.ibb.co/5B2pjyG/34ba536913c9.jpg', 32),
('https://i.ibb.co/MM0Hhmh/ae5279d45458.jpg', 'https://i.ibb.co/FxnHqLF/2f5c65dfe356.jpg', 'https://i.ibb.co/wrNcyhn/fa8ba300fe2b.jpg', 'https://i.ibb.co/1dRZK8k/282b703bbd45.jpg', 'https://i.ibb.co/r0Q99rD/f9ea43037e05.jpg', 'https://i.ibb.co/8sJPRrZ/e4bc8f380853.jpg', 33),
('https://i.ibb.co/C72bCb0/6d8ca825c306.jpg', 'https://i.ibb.co/T2WWypQ/3fc1ce8e3d2c.jpg', 'https://i.ibb.co/LzLsw5s/39dbe35c5c72.jpg', 'https://i.ibb.co/tB60CSL/d5d55c79a8ab.jpg', 'https://i.ibb.co/K5JdYKd/70b0f587a50c.jpg', 'https://i.ibb.co/ZcZVPcg/e66e7094c406.jpg', 34),
('https://i.ibb.co/qyPtZxH/3dd8e1366b92.jpg', 'https://i.ibb.co/bBKgtsd/0a6e079f9b75.jpg', 'https://i.ibb.co/J24nNd9/abd9f058b46e.jpg', 'https://i.ibb.co/JqFx3wP/79e8ee0a5987.jpg', 'https://i.ibb.co/RCKHTLZ/65c7a824fb40.jpg', 'https://i.ibb.co/3yzhHPm/8dc8089ef9d5.jpg', 35),
('https://i.ibb.co/kQQ2cqQ/f56c225c494c.jpg', 'https://i.ibb.co/71qjDy8/390f2b51ea9c.jpg', 'https://i.ibb.co/pKcLj0S/6a4b65b2511f.jpg', 'https://i.ibb.co/tB60CSL/d5d55c79a8ab.jpg', 'https://i.ibb.co/fdzTWDB/bf8581efbbdb.jpg', 'https://i.ibb.co/5B2pjyG/34ba536913c9.jpg', 36),
('https://i.ibb.co/k57b4XV/7d7bfe9d3b49.jpg', 'https://i.ibb.co/Hgtd8qT/717497de74a5.jpg', 'https://i.ibb.co/s96PNXN/8a11e782da57.jpg', 'https://i.ibb.co/wKRNGkD/5e80421e9f54.jpg', 'https://i.ibb.co/3BszzM6/b19aed55b4ea.jpg', 'https://i.ibb.co/3yzhHPm/8dc8089ef9d5.jpg', 37),
('https://i.ibb.co/xfMHPMq/63dfb8f21e3f.jpg', 'https://i.ibb.co/DQJSdSD/8dee1297cf90.jpg', 'https://i.ibb.co/pKcLj0S/6a4b65b2511f.jpg', 'https://i.ibb.co/tB60CSL/d5d55c79a8ab.jpg', 'https://i.ibb.co/8YCYxVD/65952525876a.jpg', 'https://i.ibb.co/qWLWrf5/275b58e13bc6.jpg', 38),
('https://i.ibb.co/MC3n3PV/2194436a1b78.jpg', 'https://i.ibb.co/Hgtd8qT/717497de74a5.jpg', 'https://i.ibb.co/xq4KszW/74b35c1ca524.jpg', 'https://i.ibb.co/GJjPK83/5401e2e72537.jpg', 'https://i.ibb.co/fdzTWDB/bf8581efbbdb.jpg', 'https://i.ibb.co/17mFhZ0/abd5c55090a4.jpg', 39),
('https://i.ibb.co/tsQb4CD/1f060e8c12d4.jpg', 'https://i.ibb.co/4pgJr9S/4d400712392d.jpg', 'https://i.ibb.co/s96PNXN/8a11e782da57.jpg', 'https://i.ibb.co/7vgQ3cc/b261e13dc075.jpg', 'https://i.ibb.co/X7f6gnh/321642c766e6.jpg', 'https://i.ibb.co/wCmksmT/065d2ff1f09b.jpg', 40),
('https://i.ibb.co/GCHK9LZ/b527f39a61de.jpg', 'https://i.ibb.co/C1TQWB5/f7abe2bb8b72.jpg', 'https://i.ibb.co/1X3g0Rh/24e004a64356.jpg', 'https://i.ibb.co/tB60CSL/d5d55c79a8ab.jpg', 'https://i.ibb.co/FnnNcXj/9283e4527e94.jpg', 'https://i.ibb.co/ZGcYLF1/cae121a68f36.jpg', 41),
('https://i.ibb.co/8gpHch0/9c8a14192ce1.jpg', 'https://i.ibb.co/3k3NhR4/0a8ee9f861da.jpg', 'https://i.ibb.co/r41QWgS/bc8ebf36d934.jpg', 'https://i.ibb.co/tB60CSL/d5d55c79a8ab.jpg', 'https://i.ibb.co/Lh73Fsn/1d9fae90bfe3.jpg', 'https://i.ibb.co/T0x0WJ3/cb8beb4658c9.jpg', 42),
('https://i.ibb.co/GdZJq6c/85f41d440eef.jpg', 'https://i.ibb.co/DtdwNvN/26d83483e7db.jpg', 'https://i.ibb.co/hmdVvc2/8b6309626656.jpg', 'https://i.ibb.co/3mFMWJ4/c9b9c05824a0.jpg', 'https://i.ibb.co/zncDBr6/05d7254c640b.jpg', 'https://i.ibb.co/bJ8790N/477eeedd4ea1.jpg', 43),
('https://i.ibb.co/GdZJq6c/85f41d440eef.jpg', 'https://i.ibb.co/DtdwNvN/26d83483e7db.jpg', 'https://i.ibb.co/1X3g0Rh/24e004a64356.jpg', 'https://i.ibb.co/wKRNGkD/5e80421e9f54.jpg', 'https://i.ibb.co/zncDBr6/05d7254c640b.jpg', 'https://i.ibb.co/ZcZVPcg/e66e7094c406.jpg', 44),
('https://i.ibb.co/mtzFvXk/e55fdfa851d2.jpg', 'https://i.ibb.co/v1WPBbW/94a564c63cb6.jpg', 'https://i.ibb.co/nqyfdM7/2893f24d0251.jpg', 'https://i.ibb.co/288bgcx/d9d1e0354270.jpg', 'https://i.ibb.co/PCjjcM5/f6955cbf0dc2.jpg', 'https://i.ibb.co/hWrrC6h/cf2aaba2a664.jpg', 45),
('https://i.ibb.co/JKpdvtk/35271c3cb138.jpg', 'https://i.ibb.co/Hgtd8qT/717497de74a5.jpg', 'https://i.ibb.co/BgrBPcY/6a08dc59e6ba.png', 'https://i.ibb.co/gdbvZKM/f1ff94f0f9cc.jpg', 'https://i.ibb.co/Ms1X7vp/212852dd29c7.jpg', 'https://i.ibb.co/hKCJNYv/4f74b5242d18.jpg', 46),
('https://i.ibb.co/wSDWwKY/89b68e2c902b.jpg', 'https://i.ibb.co/MkjTFRS/a73035f27621.jpg', 'https://i.ibb.co/p1CWNh1/2961b153f3b8.jpg', 'https://i.ibb.co/tB60CSL/d5d55c79a8ab.jpg', 'https://i.ibb.co/Fm8MbrM/eaab1d4b15eb.jpg', 'https://i.ibb.co/17mFhZ0/abd5c55090a4.jpg', 47),
('https://i.ibb.co/3TBQybd/6674e631aadf.jpg', 'https://i.ibb.co/ZMPS45b/9c2e8c930fb4.jpg', 'https://i.ibb.co/r41QWgS/bc8ebf36d934.jpg', 'https://i.ibb.co/wKRNGkD/5e80421e9f54.jpg', 'https://i.ibb.co/4Z9cN4X/ffdf2bd52948.jpg', 'https://i.ibb.co/5nTv8ZX/711599a33b02.jpg', 48),
('https://i.ibb.co/GdZJq6c/85f41d440eef.jpg', 'https://i.ibb.co/ZMPS45b/9c2e8c930fb4.jpg', 'https://i.ibb.co/fYLvFB9/8b6a0b4dc061.png', 'https://i.ibb.co/wKRNGkD/5e80421e9f54.jpg', 'https://i.ibb.co/X7f6gnh/321642c766e6.jpg', 'https://i.ibb.co/Sx7NSLN/74e0be740e53.jpg', 49),
('https://i.ibb.co/zFVpGdZ/634f638f4514.jpg', 'https://i.ibb.co/HrjKLYP/e93b0414d885.jpg', 'https://i.ibb.co/r41QWgS/bc8ebf36d934.jpg', 'https://i.ibb.co/vX9R7fk/bb5c387d35d4.jpg', 'https://i.ibb.co/KDKgY3H/e5423212997d.jpg', 'https://i.ibb.co/x5mCm5x/c19895b03b0b.jpg', 50),
('https://i.ibb.co/WWBGpVy/bdfac855a661.jpg', 'https://i.ibb.co/DtdwNvN/26d83483e7db.jpg', 'https://i.ibb.co/hmdVvc2/8b6309626656.jpg', 'https://i.ibb.co/jyCwhVq/5fdbf1e25fd2.jpg', 'https://i.ibb.co/23f0c8g/9f56d4f709cd.jpg', 'https://i.ibb.co/cNGWBqL/7979174b9031.jpg', 51),
('https://i.ibb.co/8gpHch0/9c8a14192ce1.jpg', 'https://i.ibb.co/MkjTFRS/a73035f27621.jpg', 'https://i.ibb.co/Rv9s0pD/d9dba3e7e5f8.jpg', 'https://i.ibb.co/jyCwhVq/5fdbf1e25fd2.jpg', 'https://i.ibb.co/8YCYxVD/65952525876a.jpg', 'https://i.ibb.co/cNGWBqL/7979174b9031.jpg', 52),
('https://i.ibb.co/zsYGgF6/c3c648c8bcaf.jpg', 'https://i.ibb.co/Hgtd8qT/717497de74a5.jpg', 'https://i.ibb.co/mDH8ytH/2b2c531d1f54.jpg', 'https://i.ibb.co/g3wNmvm/e53882e5b9f2.jpg', 'https://i.ibb.co/m9sjL9q/f862942194ff.jpg', 'https://i.ibb.co/x5mCm5x/c19895b03b0b.jpg', 53),
('https://i.ibb.co/vQLNGF0/59b7a0cf177c.jpg', 'https://i.ibb.co/HhVWRDq/ba16b63c8f41.jpg', 'https://i.ibb.co/mDH8ytH/2b2c531d1f54.jpg', 'https://i.ibb.co/QKr0wL6/3e56a949e72b.jpg', 'https://i.ibb.co/KDKgY3H/e5423212997d.jpg', 'https://i.ibb.co/ZGcYLF1/cae121a68f36.jpg', 54),
('https://i.ibb.co/XVk3RdC/35c75e05b552.jpg', 'https://i.ibb.co/ry7vKTS/c83c6dfc0386.jpg', 'https://i.ibb.co/yqCqkw3/6abfbc4771c7.jpg', 'https://i.ibb.co/RQ15cjw/2bac172b3caf.jpg', 'https://i.ibb.co/k6xYrcC/5ed790a5f00f.jpg', 'https://i.ibb.co/FWVRzv3/f151ce88aa5c.jpg', 55),
('https://i.ibb.co/Pmx2YDb/4084c667bcea.jpg', 'https://i.ibb.co/T0YHjsG/9fbb96e73426.jpg', 'https://i.ibb.co/XYt8Bw1/117f8435a402.jpg', 'https://i.ibb.co/q9mS38P/35a4c02b485d.jpg', 'https://i.ibb.co/N2rK4mH/d05df57ad73e.jpg', 'https://i.ibb.co/s25CRsz/00010bbd1322.jpg', 56);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
