-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 15, 2023 at 04:25 AM
-- Server version: 8.0.33-0ubuntu0.20.04.1
-- PHP Version: 7.4.3-4ubuntu2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `futureLove2`
--

-- --------------------------------------------------------

--
-- Table structure for table `skchiatay`
--

CREATE TABLE `skchiatay` (
  `id` int NOT NULL,
  `mask` mediumtext NOT NULL,
  `thongtin` mediumtext NOT NULL,
  `image` mediumtext NOT NULL,
  `nu` mediumtext,
  `nam` mediumtext,
  `dotuoi` int DEFAULT NULL,
  `danam` mediumtext,
  `danu` mediumtext,
  `ngswap` int DEFAULT NULL,
  `vtrinam` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `skchiatay`
--

INSERT INTO `skchiatay` (`id`, `mask`, `thongtin`, `image`, `nu`, `nam`, `dotuoi`, `danam`, `danu`, `ngswap`, `vtrinam`) VALUES
(1, 'CT', 'You two break up, when he \'helps\' my best friend out of loneliness by regularly \'having fun\' with her.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/4b8e46b44a99edfc6d585c246c6972030d9c9bb5/ct1.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/1nu.png', '0', 25, '', '2', 1, ''),
(2, 'CT', 'You and your significant other will break up because one of you deceived the other and had a third-party relationship.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/101.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/nu.101.png', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/nam.101.png', 30, '1', '', 2, 'namsau'),
(3, 'CT', 'You and your partner broke up, because you found out your partner is the third gender', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/103.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/103.jpg', '0', 30, '', '1', 1, ''),
(4, 'CT', 'The husband demanded a divorce because the wife looked too ugly after removing her makeup.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/114.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/114.jpg', '0', 27, '', '4', 1, ''),
(5, 'CT', 'You and your boyfriend will break up because he has too much money, and you don\'t like wealthy men. It just doesn\'t feel safe.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/102.jpg', '0', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/102.jpg', 35, '1', '', 1, 'nt'),
(6, 'CT', 'The boyfriend came to visit his girlfriend and got bitten by her dog. They broke up because the boyfriend said that her dog didn\'t see him as family.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/ct6.jpg', '0', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/nam6.png', 25, '1', '', 1, 'nt'),
(7, 'CT', 'She thinks this guy always does \'silly\' things to make her laugh. She likes guys with a little crazy sense of humor. But then she finds out he\'s really silly — not that', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/115.jpg', '0', '0', 25, '', '2', 1, 'nt'),
(8, 'CT', 'She tells you that their lifestyles don\'t get along because she doesn\'t want to be Catholic and doesn\'t like raising her children that way.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/3-125921317.jpg', '0', '0', 27, '', '2', 1, 'nt'),
(9, 'CT', 'He realizes that\'s not who he should marry when people fight with him every day.He listens and tries to fix it to improve the relationship but doesn\'t lose. That\'s beyond his acceptance threshold', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/4b8e46b44a99edfc6d585c246c6972030d9c9bb5/ct2.jpg', '0', '0', 25, '', '1', 1, 'nt'),
(10, 'CT', 'He broke up with me. The reason is that my hair is thin, and his hair isn\'t very thick either. He\'s afraid that if we have children, our hair will become even thinner.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/105.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/105.jpg', '0', 25, '', '4', 1, 'nt'),
(11, 'CT', 'He and I broke up because his mother said I\'m not tall enough, which would affect the future of their children. I\'m 1m60, and he\'s 1m58.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/116.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/nu116.png', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/nam116.png', 30, '4', '4', 2, 'namsau'),
(12, 'CT', 'The husband broke up with his wife because of a game that won him one billion.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/117.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/nu117.png', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/nam117.png', 40, '1', '1', 2, 'namsau'),
(13, 'CT', 'The wife demanded a breakup because the husband did not call her wife, and she thought he didn\'t love her.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/shutterstock_525808639-1.jpg', '0', '0', 40, '', '1', 1, 'nt'),
(14, 'CT', 'The wife asked for a divorce from her husband because he was too poor. She was taken care of by a wealthy man.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/108.webp', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/108.webp', '0', 40, '4', '', 1, 'nt'),
(15, 'CT', 'After 3 years of dating, the husband won the lottery and became a billionaire. He left his wife and went back to his beautiful ex-girlfriend.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/ct11.jpg', '0', '0', 35, '1', '', 1, 'nt'),
(16, 'CT', 'The wife demanded a breakup to go back to her ex-boyfriend because he became a billionaire.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/ct12.jpg', '0', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/ct12.jpg', 35, '5', '5', 1, 'nt'),
(17, 'CT', 'The wife was surprised to discover a provocative photo of her husband with his lover in her husband\'s camera.', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/ct13.jpg', '0', '0', 40, NULL, NULL, 0, 'nt');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `skchiatay`
--
ALTER TABLE `skchiatay`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
