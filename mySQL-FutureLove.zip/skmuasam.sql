-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 15, 2023 at 04:25 AM
-- Server version: 8.0.33-0ubuntu0.20.04.1
-- PHP Version: 7.4.3-4ubuntu2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `futureLove2`
--

-- --------------------------------------------------------

--
-- Table structure for table `skmuasam`
--

CREATE TABLE `skmuasam` (
  `id` int NOT NULL,
  `mask` mediumtext NOT NULL,
  `thongtin` mediumtext NOT NULL,
  `image` mediumtext NOT NULL,
  `nu` mediumtext,
  `nam` mediumtext,
  `dotuoi` int DEFAULT NULL,
  `danam` mediumtext,
  `danu` mediumtext,
  `ngswap` int DEFAULT NULL,
  `vtrinam` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `skmuasam`
--

INSERT INTO `skmuasam` (`id`, `mask`, `thongtin`, `image`, `nu`, `nam`, `dotuoi`, `danam`, `danu`, `ngswap`, `vtrinam`) VALUES
(1, 'MS', 'Because he still loved his ex-girlfriend, the husband gave her all his money, house, and car. After his wife found out, her family became homeless.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/110.jpg', '0', '0', 45, '5', '5', 0, 'nt'),
(2, 'MS', 'you and your family go bankrupt, you become homeless', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/110.jpg', '0', '0', 35, '5', '5', 0, 'nt'),
(3, 'MS', 'You will be jailed in jail for drug use', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/111.jpg', '0', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/111.jpg', 35, '2', '2', 1, 'nt'),
(4, 'MS', 'You will become the owner of a 5-star hotel chain', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/3.webp', '0', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/3.webp', 40, '2', '1', 1, 'nt'),
(5, 'MS', 'One morning, after waking up, the husband was very surprised that he had won the lottery and become wealthy.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/ms2.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/mnu5.png', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/mnam5.png', 50, '1', '2', 2, 'namsau'),
(6, 'MS', 'At the age of 45, the husband will become wealthy because his wife is the daughter of a billionaire.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/ms4.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/ms4nu.png', 'https://raw.githubusercontent.com/thuykieu06012002/cutimage/main/ms4nam.png', 45, '5', '5', 2, 'namsau'),
(7, 'MS', 'At the age of 50, you will become the president of the country.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/84153f9127573de58390f45cec550ab0-16777302887711406046058.jpg', '0', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/84153f9127573de58390f45cec550ab0-16777302887711406046058.jpg', 50, '2', '2', 1, 'nt'),
(8, 'MS', 'At the age of 35, the husband will be bought a car by his wife\'s family.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/ms1.jpg', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/ms1.jpg', '0', 35, '', '2', 2, 'namtruoc'),
(9, 'MS', 'At the age of 29, your family will have to beg for a living because the husband has sold the house for gambling.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/hinh-anh-an-xin-hai-huoc-vui-ve_095428938.jpg', '0', '0', 29, '5', '5', 0, 'nt'),
(10, 'MS', 'At the age of 50, your family will have to sell the house to pay for the husband\'s medical treatment due to his frequent alcohol consumption.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/3_thuoc_02-1675655570224.jpg', '0', '0', 50, '5', '5', 0, 'nt'),
(11, 'MS', 'At the age of 45, you have bought a villa and a luxury car.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/220119161835-02-under-40-rolls-royce-owners.jpg', '0', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/220119161835-02-under-40-rolls-royce-owners.jpg', 45, '1', '1', 1, 'nt'),
(12, 'MS', 'The house you can afford to buy at 30? It\'s an apartment', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/ms3.jpg', '0', '0', 30, '1', '1', 0, 'nt'),
(13, 'MS', 'The car you can afford to buy at the age of 30? It\'s a bicycle that belongs to both of you.', 'https://raw.githubusercontent.com/thuykieu06012002/futurelove/main/113.jpg', '0', '0', 30, '5', '5', 0, 'nt'),
(14, 'MS', 'After one year of dating, the wife was given a million-dollar mansion as a gift from her husband.', 'https://raw.githubusercontent.com/ducmanhnguyen1308/-nh-cho-future-love/main/can-biet-thu-view-bien-1649035543212.jpg', '0', '0', 25, '5', '5', 0, 'nt');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `skmuasam`
--
ALTER TABLE `skmuasam`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
